package com.easyfitness.DAO.bodymeasures;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.easyfitness.DAO.DAOBase;
import com.easyfitness.DAO.DAOUtils;
import com.easyfitness.DAO.Profile;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

public class DAOBodyMeasure extends DAOBase {


    public static final String TABLE_NAME = "EFbodymeasures";

    public static final String KEY = "_id";
    public static final String BODYPART_KEY = "bodypart_id";
    public static final String MEASURE = "mesure";
    public static final String DATE = "date";
    public static final String UNIT = "unit";
    public static final String PROFIL_KEY = "profil_id";

    public static final String TABLE_CREATE = "CREATE TABLE " + TABLE_NAME + " (" + KEY + " INTEGER PRIMARY KEY AUTOINCREMENT, " + DATE + " DATE, " + BODYPART_KEY + " INTEGER, " + MEASURE + " REAL , " + PROFIL_KEY + " INTEGER, " + UNIT + " INTEGER);";

    public static final String TABLE_DROP = "DROP TABLE IF EXISTS " + TABLE_NAME + ";";
    private Profile mProfile = null;
    private Cursor mCursor = null;

    public DAOBodyMeasure(Context context) {
        super(context);
    }

    public void setProfil(Profile pProfile) {
        mProfile = pProfile;
    }


    public void addBodyMeasure(Date pDate, int pBodymeasure_id, float pMeasure, long pProfileID) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues value = new ContentValues();

        SimpleDateFormat dateFormat = new SimpleDateFormat(DAOUtils.DATE_FORMAT);
        dateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));

        value.put(DAOBodyMeasure.DATE, dateFormat.format(pDate));
        value.put(DAOBodyMeasure.BODYPART_KEY, pBodymeasure_id);
        value.put(DAOBodyMeasure.MEASURE, pMeasure);
        value.put(DAOBodyMeasure.PROFIL_KEY, pProfileID);

        db.insert(DAOBodyMeasure.TABLE_NAME, null, value);
        db.close();
    }


    private BodyMeasure getMeasure(long id) {
        SQLiteDatabase db = this.getReadableDatabase();

        mCursor = null;
        mCursor = db.query(TABLE_NAME,
            new String[]{KEY, DATE, BODYPART_KEY, MEASURE, PROFIL_KEY},
            KEY + "=?",
            new String[]{String.valueOf(id)},
            null, null, null, null);
        if (mCursor != null)
            mCursor.moveToFirst();

        Date date;
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat(DAOUtils.DATE_FORMAT);
            dateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
            date = dateFormat.parse(mCursor.getString(1));
        } catch (ParseException e) {
            e.printStackTrace();
            date = new Date();
        }

        BodyMeasure value = new BodyMeasure(mCursor.getLong(0),
            date,
            mCursor.getInt(2),
            mCursor.getFloat(3),
            mCursor.getLong(4)
        );

        db.close();


        return value;
    }


    private List<BodyMeasure> getMeasuresList(String pRequest) {
        List<BodyMeasure> valueList = new ArrayList<>();


        SQLiteDatabase db = this.getReadableDatabase();
        mCursor = null;
        mCursor = db.rawQuery(pRequest, null);


        if (mCursor.moveToFirst()) {
            do {
                Date date;
                try {
                    SimpleDateFormat dateFormat = new SimpleDateFormat(DAOUtils.DATE_FORMAT);
                    dateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
                    date = dateFormat.parse(mCursor.getString(1));
                } catch (ParseException e) {
                    e.printStackTrace();
                    date = new Date();
                }

                BodyMeasure value = new BodyMeasure(mCursor.getLong(0),
                    date,
                    mCursor.getInt(2),
                    mCursor.getFloat(3),
                    mCursor.getLong(4)
                );

                valueList.add(value);
            } while (mCursor.moveToNext());
        }


        return valueList;
    }

    public Cursor getCursor() {
        return mCursor;
    }


    public List<BodyMeasure> getBodyPartMeasuresList(long pBodyPartID, Profile pProfile) {

        String selectQuery = "SELECT * FROM " + TABLE_NAME + " WHERE " + BODYPART_KEY + "=" + pBodyPartID + " AND " + PROFIL_KEY + "=" + pProfile.getId() + " GROUP BY " + DATE + " ORDER BY date(" + DATE + ") DESC";


        return getMeasuresList(selectQuery);
    }

    public List<BodyMeasure> getBodyMeasuresList(Profile pProfile) {
        // Select All Query
        String selectQuery = "SELECT * FROM " + TABLE_NAME + " WHERE " + PROFIL_KEY + "=" + pProfile.getId() + " ORDER BY date(" + DATE + ") DESC";


        return getMeasuresList(selectQuery);
    }


    public BodyMeasure getLastBodyMeasures(long pBodyPartID, Profile pProfile) {

        String selectQuery = "SELECT * FROM " + TABLE_NAME + " WHERE " + BODYPART_KEY + "=" + pBodyPartID + " AND " + PROFIL_KEY + "=" + pProfile.getId() + " GROUP BY " + DATE + " ORDER BY date(" + DATE + ") DESC";

        List<BodyMeasure> array = getMeasuresList(selectQuery);
        if (array.size() <= 0) {
            return null;
        }


        return getMeasuresList(selectQuery).get(0);
    }


    public int updateMeasure(BodyMeasure m) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues value = new ContentValues();
        SimpleDateFormat dateFormat = new SimpleDateFormat(DAOUtils.DATE_FORMAT);
        dateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
        String dateString = dateFormat.format(m.getDate());
        value.put(DAOBodyMeasure.DATE, dateString);
        value.put(DAOBodyMeasure.BODYPART_KEY, m.getBodyPartID());
        value.put(DAOBodyMeasure.MEASURE, m.getBodyMeasure());
        value.put(DAOBodyMeasure.PROFIL_KEY, m.getProfileID());


        return db.update(TABLE_NAME, value, KEY + " = ?",
            new String[]{String.valueOf(m.getId())});
    }


    public void deleteMeasure(long id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NAME, KEY + " = ?",
            new String[]{String.valueOf(id)});
    }


    public int getCount() {
        String countQuery = "SELECT * FROM " + TABLE_NAME;
        open();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);

        int value = cursor.getCount();
        cursor.close();
        close();

        return value;
    }

    public void populate() {
        Date date = new Date();
        int poids = 10;

        for (int i = 1; i <= 5; i++) {
            date.setTime(date.getTime() + i * 1000 * 60 * 60 * 24 * 2);

        }
    }
}


